<?php

namespace App\Controllers\Dtks;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use App\Models\Dtks\StudentModel;

class CsvReportController extends Controller
{
    public function index()
    {
        return view('index');
    }
}
