<?= $this->include('profil/templates/head'); ?>

<?= $this->include('templates/navbar'); ?>

<!-- Main Sidebar Container -->
<?= $this->include('templates/sidebar'); ?>

<?= $this->renderSection('content'); ?>

<?= $this->include('profil/templates/footer'); ?>