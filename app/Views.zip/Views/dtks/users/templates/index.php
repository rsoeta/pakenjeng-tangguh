<?= $this->include('dtks/templates/head'); ?>

<?= $this->include('dtks/templates/navbar'); ?>

<!-- Main Sidebar Container -->
<?= $this->include('dtks/templates/sidebar'); ?>

<?= $this->renderSection('content'); ?>

<?= $this->include('dtks/templates/footer'); ?>