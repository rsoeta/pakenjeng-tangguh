<?php

namespace App\Models\Dtks;

use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;

class CsvReportModel extends Model
{
    protected $table = 'dtks_csv_report';
    protected $allowedFields = [
        'cr_nama_kec',
        'cr_nama_desa',
        'cr_nik_usulan',
        'cr_program_bansos',
        'cr_hasil',
        'cr_padan',
        'cr_nama_lgkp',
        'cr_ket_vali',
        'cr_created_by',
        'cr_created_at',
    ];
}
